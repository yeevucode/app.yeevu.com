// js/common.js

// Universal function to display messages
export function displayMessage(message, type = 'info') {
    const formMessageDiv = document.getElementById('form-message');
    if (!formMessageDiv) {
        console.error('Error: form-message div not found! Please ensure your HTML includes <div id="form-message"></div>');
        // Fallback to console.log if the message div isn't found
        console.log(`Message (${type}): ${message}`); 
        return;
    }
    formMessageDiv.textContent = message;
    formMessageDiv.style.display = 'block';
    formMessageDiv.style.backgroundColor = ''; // Reset
    formMessageDiv.style.color = ''; // Reset
    formMessageDiv.style.border = ''; // Reset
    formMessageDiv.style.padding = '10px'; // Ensure padding
    formMessageDiv.style.borderRadius = '5px'; // Add some styling

    if (type === 'success') {
        formMessageDiv.style.backgroundColor = '#d4edda'; /* Light green */
        formMessageDiv.style.color = '#155724'; /* Dark green */
        formMessageDiv.style.borderColor = '#c3e6cb';
    } else if (type === 'error') {
        formMessageDiv.style.backgroundColor = '#f8d7da'; /* Light red */
        formMessageDiv.style.color = '#721c24'; /* Dark red */
        formMessageDiv.style.borderColor = '#f5c6cb';
    } else { /* info */
        formMessageDiv.style.backgroundColor = '#e2e3e5'; /* Light gray */
        formMessageDiv.style.color = '#383d41'; /* Dark gray */
        formMessageDiv.style.borderColor = '#d6d8db';
    }
}

// Auth0 configuration
export const AUTH0_DOMAIN = 'yeevu.us.auth0.com';
export const AUTH0_CLIENT_ID = 'pXvpjzqZFTVZhdV6xXNQqer4gGgr6W9g';
export const AUTH0_REDIRECT_URI = 'https://ai.yeevu.com/callback/'; // IMPORTANT: Ensure trailing slash if it's a directory
export const AUTH0_AUDIENCE = 'https://yeevu.us.auth0.com/api/v2/';

// --- Auth Actions ---
export function login() {
    displayMessage('Redirecting to login page...', 'info'); 
    const returnToPath = window.location.pathname + window.location.search;
    window.location.href = `https://${AUTH0_DOMAIN}/authorize?response_type=token&client_id=${AUTH0_CLIENT_ID}&redirect_uri=${AUTH0_REDIRECT_URI}&scope=openid profile email&audience=${AUTH0_AUDIENCE}&state=${encodeURIComponent(returnToPath)}`;
}

export function signup() {
    displayMessage('Redirecting to signup page...', 'info'); 
    const returnToPath = window.location.pathname + window.location.search;
    window.location.href = `https://${AUTH0_DOMAIN}/authorize?response_type=token&client_id=${AUTH0_CLIENT_ID}&redirect_uri=${AUTH0_REDIRECT_URI}&scope=openid profile email&audience=${AUTH0_AUDIENCE}&screen_hint=signup&state=${encodeURIComponent(returnToPath)}`;
}

export function subscribe() {
    displayMessage('Redirecting to subscription page...', 'info'); 
    window.location.href = 'https://portal.tkwebhosts.com/cart.php';
}

// --- Handle Auth Token (now primarily reads from localStorage) ---
export function handleTokenFromHash() {
    const hash = window.location.hash;
    console.log('Common JS: Checking for token in hash:', hash);
    if (hash.includes('access_token')) {
        const params = new URLSearchParams(hash.replace('#', ''));
        const token = params.get('access_token');
        if (token) {
            localStorage.setItem('token', token);
            window.location.hash = ''; // Clear hash to prevent re-processing
            console.log('Common JS: Token found in hash and stored:', token);
            return token;
        }
    }
    const storedToken = localStorage.getItem('token');
    console.log('Common JS: Stored token from localStorage:', storedToken);
    return storedToken;
}

// --- Check Subscription Status via N8N ---
export async function checkSubscription() {
    const token = localStorage.getItem('token');
    console.log('Common JS: Checking subscription, token:', token ? 'exists' : 'null'); 
    if (!token) return null; // No token, no check

    try {
        const response = await fetch('https://n8n.tomiwa.io/webhook/api/user/subscription', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}` // N8N uses this to authenticate and get user info
            }
        });
        console.log('Common JS: Subscription response status:', response.status);

        if (response.status === 401) {
            // Token is invalid/expired on the server-side, clear it
            localStorage.removeItem('token');
            console.warn('Common JS: Authentication failed for subscription check. Token removed.');
            return null;
        }

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Common JS: Subscription API fetch failed: ${response.status} - ${errorText}`);
        }

        const data = await response.json(); // <-- THIS 'data' SHOULD NOW BE YOUR FULL USER OBJECT with subscriptionList
        console.log('Common JS: Subscription data (from N8N API):', data);

        // Ensure subscriptionList is an array, even if the API returns null or undefined
        if (!Array.isArray(data.subscriptionList)) {
            data.subscriptionList = [];
            console.warn('Common JS: user.subscriptionList is not an array. Initialized as empty array.');
        }

        return data; // Return the user object
    } catch (error) {
        console.error('Common JS: Subscription check error:', error);
        localStorage.removeItem('token'); // Clear token on network/API errors as well
        return null;
    }
}

// --- Wait for buttons to appear before attaching events (for dynamically loaded elements) ---
export function waitForElement(id, callback, timeout = 5000) {
    let el = document.getElementById(id);
    if (el) {
        console.log(`✅ Common JS waitForElement: Found '${id}' immediately.`);
        return callback(el);
    }

    console.log(`⏳ Common JS waitForElement: Starting observer for '${id}'...`);
    let observer = null;
    let timeoutId = null;

    const checkElement = () => {
        el = document.getElementById(id);
        if (el) {
            if (observer) observer.disconnect();
            if (timeoutId) clearTimeout(timeoutId);
            console.log(`✅ Common JS waitForElement: Found '${id}' via check/observer.`);
            callback(el);
            return true;
        }
        return false;
    };

    if (checkElement()) return;

    observer = new MutationObserver((mutationsList, obs) => {
        if (checkElement()) {
            obs.disconnect();
        }
    });

    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'display', 'class'] });

    timeoutId = setTimeout(() => {
        if (observer) observer.disconnect();
        el = document.getElementById(id);
        if (el) {
            console.warn(`⚠️ Common JS waitForElement: Found '${id}' late via timeout fallback.`);
            callback(el);
        } else {
            console.error(`❌ Common JS waitForElement: Element '${id}' not found after ${timeout / 1000} seconds.`);
        }
    }, timeout);
}