// web-designer/script.js

// Import common utilities from the centralized common.js file
import { 
    displayMessage, 
    login, 
    signup, 
    subscribe, 
    handleTokenFromHash, 
    checkSubscription 
} from '../js/common.js'; // Adjust path if common.js is elsewhere relative to this file

document.addEventListener('DOMContentLoaded', () => {
    let user = null; // This will hold user and subscription data from N8N (now includes subscriptionList)

    // --- DOM Elements ---
    const loginPrompt = document.getElementById('loginPrompt');
    const paywallOverlay = document.getElementById('paywallOverlay');
    const mainContent = document.getElementById('mainContent'); // The wrapper div for your forms
    const tabButtons = document.querySelectorAll('.resolver-selector .mode-btn');
    const forms = document.querySelectorAll('.resolver-form');
    const webhookResponseTextarea = document.getElementById('webhook-response');

    // --- Paywall & Access Control Logic ---

    // Define the specific subscription code required for each Web Designer mode
    // Assuming 'wd-lifetime' includes 'wd-premium', and 'wd-premium' includes 'wd-basic'
    const WD_MODE_SUBSCRIPTION_REQUIREMENTS = {
        'starter': ['wd-basic', 'wd-premium', 'wd-lifetime'],
        'standard': ['wd-premium', 'wd-lifetime'],
        'professional': ['wd-lifetime']
    };

    function isRestricted(mode) {
        // If user is not logged in, or has no subscriptionList, or subscriptionList is empty, restrict access.
        if (!user || !Array.isArray(user.subscriptionList) || user.subscriptionList.length === 0) {
            console.log(`Restriction: ${mode} requires login or an active subscription.`);
            return true;
        }

        const userSubscriptions = user.subscriptionList; // Get the array of user's subscriptions
        const requiredCodesForMode = WD_MODE_SUBSCRIPTION_REQUIREMENTS[mode];

        if (!requiredCodesForMode) {
            console.warn(`Unknown mode '${mode}' encountered. Defaulting to restricted.`);
            return true; // Unknown modes are restricted
        }

        // Check if the user has ANY of the required subscriptions for the given mode
        const hasAccess = requiredCodesForMode.some(requiredCode => userSubscriptions.includes(requiredCode));

        if (!hasAccess) {
            console.log(`Restriction: ${mode} requires one of [${requiredCodesForMode.join(', ')}]. User subscriptions: [${userSubscriptions.join(', ')}]`);
            return true;
        }

        return false; // User has access
    }

    function updateUIAccess() {
        // Hide all elements by default
        loginPrompt.style.display = 'none';
        paywallOverlay.style.display = 'none';
        mainContent.style.display = 'none';
        displayMessage(''); // Clear any messages

        if (!user) {
            // User not logged in
            loginPrompt.style.display = 'block';
            console.log('UI State: Showing Login Prompt.');
        } else {
            // User is logged in, check if their current subscription allows minimal access (e.g., 'starter' tier)
            if (isRestricted('starter')) { // Check if even the base 'starter' tier is restricted
                paywallOverlay.style.display = 'flex'; // Use 'flex' for overlay to center content
                displayMessage('You are logged in, but your current subscription does not include access to the AI Web Designer. Please upgrade your plan.', 'info');
                console.log('UI State: User logged in, but subscription is insufficient for any tier. Showing Paywall.');
            } else {
                // User is logged in and has sufficient subscription for at least 'starter'
                mainContent.style.display = 'block';
                console.log('UI State: User logged in and subscribed. Showing Main Content.');
                // Ensure the 'Starter' tab is active and its form is displayed
                showTab('starter');
            }
        }
    }

    // --- Tab Switching Logic ---
    function showTab(tabId) {
        forms.forEach(form => {
            form.style.display = 'none'; // Hide all forms
        });
        tabButtons.forEach(btn => {
            btn.classList.remove('active'); // Deactivate all buttons
            btn.setAttribute('aria-selected', 'false');
        });

        const activeForm = document.getElementById(`form-${tabId}`);
        if (activeForm) {
            activeForm.style.display = 'block'; // Show active form
            document.getElementById(`tab-${tabId}`).classList.add('active'); // Activate button
            document.getElementById(`tab-${tabId}`).setAttribute('aria-selected', 'true');
        } else {
            console.error(`Form with ID 'form-${tabId}' not found.`);
        }
        // Clear messages and webhook response when switching tabs
        displayMessage('');
        webhookResponseTextarea.value = '';
        webhookResponseTextarea.style.display = 'none'; // Hide response box
    }

    tabButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const mode = e.target.dataset.mode;
            console.log(`Tab clicked: ${mode}`);

            if (isRestricted(mode)) {
                // If restricted, show paywall overlay and prevent tab switch
                paywallOverlay.style.display = 'flex'; // Use 'flex' for overlay to center content
                displayMessage(`To access the ${mode.charAt(0).toUpperCase() + mode.slice(1)} plan, please upgrade your subscription.`, 'info');
                
                // Revert to the previously active tab/form if possible
                const currentActiveTab = document.querySelector('.mode-btn.active');
                if (currentActiveTab) {
                    showTab(currentActiveTab.dataset.mode); // Re-show current active tab
                } else {
                    // Fallback: If no tab was active (e.g., first click on restricted tab),
                    // ensure Starter is shown if user has access to it.
                    if (!isRestricted('starter')) { // Check if user has access to starter
                        showTab('starter');
                    } else {
                        // If even starter is restricted, it means the entire mainContent should be hidden
                        // and paywall shown, which updateUIAccess() already does.
                        mainContent.style.display = 'none'; // Ensure main content is hidden if no valid tab can be shown
                    }
                }
                return;
            }

            // If not restricted, proceed with tab switching
            paywallOverlay.style.display = 'none'; // Ensure paywall is hidden
            displayMessage(''); // Clear any previous messages
            showTab(mode);
        });
    });

    // --- Form Submission Logic ---
    // The webhook URL is taken directly from the form's action attribute in the HTML.
    // This allows different forms to submit to different webhooks if needed.

    async function handleFormSubmit(event, formElement) {
        event.preventDefault();

        const mode = formElement.id.replace('form-', '');

        // Re-check status before submission
        if (isRestricted(mode)) {
            displayMessage(`To submit the ${mode.charAt(0).toUpperCase() + mode.slice(1)} plan, please upgrade your subscription.`, 'error');
            paywallOverlay.style.display = 'flex'; // Use 'flex' for overlay
            return;
        }

        const formData = new FormData(formElement);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        
        // Add the product_tier from the form itself
        data['product_tier'] = mode;

        try {
            const token = localStorage.getItem('token');
            // If token is missing for a form that requires it, redirect to login
            if (!token) {
                displayMessage('You must be logged in to submit this form. Please sign in.', 'error');
                loginPrompt.style.display = 'block';
                mainContent.style.display = 'none';
                return;
            }

            displayMessage('Submitting...', 'info');
            webhookResponseTextarea.value = '';
            webhookResponseTextarea.style.display = 'none'; // Hide until populated

            // Use the specific form's action URL for submission
            const response = await fetch(formElement.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}` // Send Auth0 token to N8N
                },
                body: JSON.stringify(data),
            });

            if (response.status === 403) { // Forbidden - likely subscription tier issue
                displayMessage('Unauthorized: Your current subscription does not allow submission for this plan. Please upgrade.', 'error');
                paywallOverlay.style.display = 'flex'; // Use 'flex' for overlay
                return;
            }
            if (response.status === 401) { // Unauthorized - token invalid/expired
                displayMessage('Authentication failed. Your session may have expired. Please log in again.', 'error'); // More explicit message
                localStorage.removeItem('token'); // Clear invalid token
                user = null; // Reset user state
                updateUIAccess(); // Re-render UI to show login prompt
                return;
            }

            if (response.ok) {
                const result = await response.json();
                webhookResponseTextarea.value = JSON.stringify(result, null, 2); // For debugging
                webhookResponseTextarea.style.display = 'block'; // Show response box

                if (result.status === 'success') {
                    displayMessage(result.message || 'Form submitted successfully!', 'success');
                    formElement.reset(); // Clear the form on successful submission
                } else {
                    displayMessage(result.message || 'An error occurred during processing.', 'error');
                }
            } else {
                let errorText = await response.text();
                try {
                    const errorJson = JSON.parse(errorText);
                    errorText = errorJson.message || errorText;
                } catch (e) { /* not JSON, use raw text */ }
                displayMessage(`Submission failed: ${response.status} ${response.statusText}. ${errorText}`, 'error');
            }
        } catch (error) {
            displayMessage('Network Error: Could not connect to the server. Please try again.', 'error');
            webhookResponseTextarea.value = 'Error: ' + error.message; // For detailed debug
            webhookResponseTextarea.style.display = 'block';
        }
    }

    // Attach submit listeners to each form
    document.getElementById('form-starter')?.addEventListener('submit', (e) => handleFormSubmit(e, e.target));
    document.getElementById('form-standard')?.addEventListener('submit', (e) => handleFormSubmit(e, e.target));
    document.getElementById('form-professional')?.addEventListener('submit', (e) => handleFormSubmit(e, e.target));

    // Event Listeners for login/signup/subscribe buttons
    const loginBtn = document.getElementById('loginBtn');
    const signupBtn = document.getElementById('signupBtn');
    const subscribeBtn = document.getElementById('subscribeBtn');

    if (loginBtn) {
        loginBtn.addEventListener('click', login);
    }
    if (signupBtn) {
        signupBtn.addEventListener('click', signup);
    }
    if (subscribeBtn) {
        subscribeBtn.addEventListener('click', subscribe);
    }

    // Close paywall overlay when clicking outside content
    if (paywallOverlay) {
        paywallOverlay.addEventListener('click', (e) => {
            if (e.target === paywallOverlay) {
                paywallOverlay.style.display = 'none';
                displayMessage(''); // Clear message when closing overlay
            }
        });
    }

    // --- App Initialization Logic ---
    console.log('--- Initializing Web Designer App ---');
    // On page load, try to get token from localStorage (set by callback.js or previous session)
    handleTokenFromHash(); // Cleans hash and stores token if present (unlikely on main page, but good for robustness)

    checkSubscription()
        .then(userData => { // Capture the returned user data
            user = userData; // Assign the fetched user data to the local 'user' variable
            updateUIAccess(); // Now update the UI based on the fetched user state
        })
        .catch(err => {
            console.error('App initialization error (subscription check failed):', err);
            updateUIAccess(); // Fallback to update UI even if check fails (user will be null)
        });
});